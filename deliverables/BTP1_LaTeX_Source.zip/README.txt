Main file: main.tex
Compile with pdfLaTeX, XeLaTeX or Tectonic. All figures and generated numerical sections are included.
